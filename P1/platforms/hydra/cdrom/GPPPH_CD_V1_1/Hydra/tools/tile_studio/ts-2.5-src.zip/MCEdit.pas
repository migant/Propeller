unit MCEdit;

  { TILE STUDIO

    Web site:    http://tilestudio.sourceforge.net/

    Written by:  Mike Wiering, University of Nijmegen
    E-mail:      mike@wieringsoftware.nl

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of the
    License, or (at your option) any later version.  See the file
    COPYING included with this distribution for more information.
  }

  {$I SETTINGS.INC}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Spin;

const
  MAX_CODE = 255;

type
  TMapCode = class(TForm)
    L1: TLabel;
    L2: TLabel;
    DecCode: TSpinEdit;
    HexCode: TEdit;
    OkButton: TButton;
    CancelButton: TButton;
    procedure OkButtonClick(Sender: TObject);
    procedure CancelButtonClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure CheckDecCode(Sender: TObject);
    procedure HexCodeChange(Sender: TObject);
    procedure MapCodeKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
  private
    { Private declarations }
  public
    { Public declarations }
    OldValue,
    Value: Integer;
    Result: Boolean;
    SkipUpdate: Boolean;
  end;

var
  MapCode: TMapCode;

implementation

{$R *.DFM}

uses
  Hex;

procedure TMapCode.OkButtonClick(Sender: TObject);
begin
  Result := TRUE;
  Close;
end;

procedure TMapCode.CancelButtonClick(Sender: TObject);
begin
  Value := OldValue;
  Result := FALSE;
  Close;
end;

procedure TMapCode.FormShow(Sender: TObject);
begin
  Result := FALSE;
  OldValue := Value;
  HexCode.Text := Hex2 (Value);
  DecCode.Text := IntToStr (Value);
  SkipUpdate := FALSE;
  HexCode.SetFocus;
end;

procedure TMapCode.CheckDecCode(Sender: TObject);
  var
    n, c: Integer;
begin
  if SkipUpdate then
    Exit;
  Val (DecCode.Text, n, c);
  if (c = 0) and (n >= 0) and (n <= MAX_CODE) then
  begin
    SkipUpdate := TRUE;
    HexCode.Text := Hex2 (n);
    SkipUpdate := FALSE;
    Value := n;
    OkButton.Enabled := TRUE;
  end
  else
    OkButton.Enabled := FALSE;
end;

procedure TMapCode.HexCodeChange(Sender: TObject);
  var
    n, c: Integer;
begin
  if SkipUpdate then
    Exit;
  Val ('$' + HexCode.Text, n, c);
  if (c = 0) and (n >= 0) and (n <= MAX_CODE) then
  begin
    SkipUpdate := TRUE;
    DecCode.Text := IntToStr (n);
    SkipUpdate := FALSE;
    Value := n;
    OkButton.Enabled := TRUE;
  end
  else
    OkButton.Enabled := FALSE;
end;

procedure TMapCode.MapCodeKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if Key = VK_RETURN then
    OkButtonClick (Sender);
  if Key = VK_ESCAPE then
    CancelButtonClick (Sender);
end;

end.
