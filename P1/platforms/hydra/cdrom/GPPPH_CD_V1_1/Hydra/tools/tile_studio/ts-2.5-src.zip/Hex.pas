unit Hex;

  { TILE STUDIO

    Web site:    http://tilestudio.sourceforge.net/

    Written by:  Mike Wiering, University of Nijmegen
    E-mail:      mike@wieringsoftware.nl

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of the
    License, or (at your option) any later version.  See the file
    COPYING included with this distribution for more information.
  }

interface

  const
    HexChars: array[0..$F] of Char =
      ('0', '1', '2', '3', '4', '5', '6', '7',
       '8', '9', 'A', 'B', 'C', 'D', 'E', 'F');

  function Hex2 (b: Byte): string;
  function Hex4 (w: Word): string;
  function Hex8 (l: LongInt): string;

implementation

  function Hex2 (b: Byte): string;
  begin
    Hex2 := HexChars[b shr 4] + HexChars[b and $0F];
  end;

  function Hex4 (w: Word): string;
  begin
    Hex4 := Hex2 (Hi (w)) + Hex2 (Lo (w));
  end;

  function Hex8 (l: LongInt): string;
    var
      W: array[0..1] of Word absolute l;
  begin
    Hex8 := Hex4 (W[1]) + Hex4 (W[0]);
  end;

end.
