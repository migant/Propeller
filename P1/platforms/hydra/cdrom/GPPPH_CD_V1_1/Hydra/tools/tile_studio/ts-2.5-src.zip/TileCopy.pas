unit TileCopy;

  { TILE STUDIO

    Web site:    http://tilestudio.sourceforge.net/

    Written by:  Mike Wiering, University of Nijmegen
    E-mail:      mike@wieringsoftware.nl

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of the
    License, or (at your option) any later version.  See the file
    COPYING included with this distribution for more information.
  }

  {$I SETTINGS.INC}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Spin;

type
  TCopyTilesForm = class(TForm)
    OkButton: TButton;
    CancelButton: TButton;
    G1: TGroupBox;
    L1: TLabel;
    L3: TLabel;
    L4: TLabel;
    Src: TComboBox;
    StartTile: TSpinEdit;
    TileCount: TSpinEdit;
    G2: TGroupBox;
    L2: TLabel;
    Dst: TComboBox;
    L5: TLabel;
    DstStartTile: TSpinEdit;
    Overwrite: TCheckBox;
    Stretch: TCheckBox;
    CopyBounds: TCheckBox;
    procedure OkButtonClick(Sender: TObject);
    procedure CancelButtonClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure CheckInput(Sender: TObject);
    procedure CopyTilesKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
  private
    { Private declarations }
  public
    { Public declarations }
    Result: Boolean;
  end;

var
  CopyTilesForm: TCopyTilesForm;

implementation

uses Main;

{$R *.DFM}

procedure TCopyTilesForm.OkButtonClick(Sender: TObject);
begin
  if Src.Items.IndexOf (Src.Text) < 0 then
  begin
    MessageDlg ('Source Tile Set doesn'#39't exist.', mtError, [mbOk], 0);
    Src.SetFocus;
    Exit;
  end;
  if Dst.Items.IndexOf (Dst.Text) < 0 then
  begin
    MessageDlg ('Destination Tile Set doesn'#39't exist.', mtError, [mbOk], 0);
    Dst.SetFocus;
    Exit;
  end;


//  MessageDlg ('Not yet implemented.', mtError, [mbOk], 0);

  Result := TRUE;
  Close;
end;

procedure TCopyTilesForm.CancelButtonClick(Sender: TObject);
begin
  Close;
end;

procedure TCopyTilesForm.FormShow(Sender: TObject);
begin
  Result := FALSE;
  Src.SetFocus;
  CheckInput (Sender);
end;

procedure TCopyTilesForm.CheckInput(Sender: TObject);
  var
    i, j, W, H: Integer;
begin
  i := Src.Items.IndexOf (Src.Text);
  if i >= 0 then
  begin
    with MainForm.TileTab[i] do
      if Sender = Src then
      begin
        StartTile.Value := tbr.Current + 1;
        TileCount.Value := tbr.TileCount - tbr.Current;
        StartTile.MaxValue := tbr.TileCount;
        TileCount.MaxValue := tbr.TileCount;
      end;
  end;

  i := Dst.Items.IndexOf (Dst.Text);
  if i >= 0 then
  begin
    with MainForm.TileTab[i] do
    begin
      if Sender = Dst then
      begin
        DstStartTile.Value := tbr.Current + 1;
        DstStartTile.MaxValue := tbr.TileCount;
      end;
      W := tbr.W;
      H := tbr.H;
      j := Src.Items.IndexOf (Src.Text);
      if j >= 0 then
        with MainForm.TileTab[j] do
          Stretch.Enabled := (tbr.W <> W) or (tbr.H <> H);
    end;
  end;

end;

procedure TCopyTilesForm.CopyTilesKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if Key = VK_RETURN then
    OkButtonClick (Sender);
  if Key = VK_ESCAPE then
    CancelButtonClick (Sender);
end;

end.
