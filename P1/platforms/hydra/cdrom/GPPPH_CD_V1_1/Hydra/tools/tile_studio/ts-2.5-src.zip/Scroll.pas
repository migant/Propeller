unit Scroll;

  { TILE STUDIO

    Web site:    http://tilestudio.sourceforge.net/

    Written by:  Mike Wiering, University of Nijmegen
    E-mail:      mike@wieringsoftware.nl

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of the
    License, or (at your option) any later version.  See the file
    COPYING included with this distribution for more information.
  }

  {$I SETTINGS.INC}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TMapScroll = class(TForm)
    OkButton: TButton;
    CancelButton: TButton;
    X: TEdit;
    L1: TLabel;
    Y: TEdit;
    L2: TLabel;
    Label1: TLabel;
    procedure YKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormShow(Sender: TObject);
    procedure OkButtonClick(Sender: TObject);
    procedure CancelButtonClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    Result: Boolean;
  end;

var
  MapScroll: TMapScroll;

implementation

{$R *.DFM}

procedure TMapScroll.YKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if key = VK_ESCAPE then
    CancelButtonClick (Sender);
  if key = VK_RETURN then
    OKButtonClick (Sender);
end;

procedure TMapScroll.FormShow(Sender: TObject);
begin
  Result := FALSE;
  X.SetFocus;
end;

procedure TMapScroll.OkButtonClick(Sender: TObject);
begin
  Result := TRUE;
  Close;
end;

procedure TMapScroll.CancelButtonClick(Sender: TObject);
begin
  Close;
end;

end.
