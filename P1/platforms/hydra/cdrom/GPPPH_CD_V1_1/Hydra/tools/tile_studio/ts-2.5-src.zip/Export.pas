unit Export;

  { TILE STUDIO

    Web site:    http://tilestudio.sourceforge.net/

    Written by:  Mike Wiering, University of Nijmegen
    E-mail:      mike@wieringsoftware.nl

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of the
    License, or (at your option) any later version.  See the file
    COPYING included with this distribution for more information.
  }

  {$I SETTINGS.INC}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Spin, ExtCtrls;

type
  TExportTiles = class(TForm)
    L7: TLabel;
    TransColor: TShape;
    ExportButton: TButton;
    CancelButton: TButton;
    Label1: TLabel;
    BorderColor: TShape;
    Label2: TLabel;
    MaxWidth: TSpinEdit;
    ColorDialog: TColorDialog;
    Label3: TLabel;
    Between: TSpinEdit;
    Label4: TLabel;
    Edge: TSpinEdit;
    TransBottomRight: TCheckBox;
    procedure FormShow(Sender: TObject);
    procedure ExportButtonClick(Sender: TObject);
    procedure CancelButtonClick(Sender: TObject);
    procedure TransColorMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure KeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure BorderColorMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
  private
    { Private declarations }
  public
    { Public declarations }
    Result: Boolean;
  end;

var
  ExportTiles: TExportTiles;

implementation

{$R *.DFM}

uses
  Tiles;

procedure TExportTiles.FormShow(Sender: TObject);
  const
    Initialized: Boolean = FALSE;
begin
  Result := FALSE;

  if not Initialized then
  begin
    TransColor.Brush.Color := TRANS_COLOR;
    BorderColor.Brush.Color := TRANS_COLOR;
    Initialized := TRUE;
  end;

  MaxWidth.SetFocus;
end;

procedure TExportTiles.ExportButtonClick(Sender: TObject);
begin
  Result := TRUE;
  Close;
end;

procedure TExportTiles.CancelButtonClick(Sender: TObject);
begin
  Close;
end;

procedure TExportTiles.TransColorMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  ColorDialog.Color := TransColor.Brush.Color;
  if ColorDialog.Execute then
    TransColor.Brush.Color := ColorDialog.Color;
end;

procedure TExportTiles.KeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if key = VK_RETURN then
    ExportButtonClick (Sender);
  if key = VK_ESCAPE then
    CancelButtonClick (Sender);
end;

procedure TExportTiles.BorderColorMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  ColorDialog.Color := BorderColor.Brush.Color;
  if ColorDialog.Execute then
    BorderColor.Brush.Color := ColorDialog.Color;
end;

end.
