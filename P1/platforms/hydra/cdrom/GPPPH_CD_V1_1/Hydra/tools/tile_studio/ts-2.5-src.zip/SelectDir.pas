unit SelectDir;

  { TILE STUDIO

    Web site:    http://tilestudio.sourceforge.net/

    Written by:  Mike Wiering, University of Nijmegen
    E-mail:      mike@wieringsoftware.nl

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of the
    License, or (at your option) any later version.  See the file
    COPYING included with this distribution for more information.
  }

  {$I SETTINGS.INC}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, FileCtrl;

type
  TOutputDir = class(TForm)
    OkButton: TButton;
    CancelButton: TButton;
    DirectoryListBox: TDirectoryListBox;
    DriveComboBox: TDriveComboBox;
    L2: TLabel;
    L1: TLabel;
    procedure FormShow(Sender: TObject);
    procedure CancelButtonClick(Sender: TObject);
    procedure OkButtonClick(Sender: TObject);
    procedure KeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
  private
    { Private declarations }
  public
    { Public declarations }
    Result: Boolean;
  end;

var
  OutputDir: TOutputDir;

implementation

{$R *.DFM}

procedure TOutputDir.FormShow(Sender: TObject);
begin
  Result := FALSE;
  DirectoryListBox.SetFocus;

end;

procedure TOutputDir.CancelButtonClick(Sender: TObject);
begin
  Close;
end;

procedure TOutputDir.OkButtonClick(Sender: TObject);
begin
  Result := TRUE;
  Close;
end;

procedure TOutputDir.KeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if Key = VK_ESCAPE then
    CancelButtonClick (Sender);
  if Key = VK_RETURN then
    OKButtonClick (Sender);
end;

end.
