unit About;

  { TILE STUDIO

    Web site:    http://tilestudio.sourceforge.net/

    Written by:  Mike Wiering, Wiering Software
    E-mail:      mike@wieringsoftware.nl

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of the
    License, or (at your option) any later version.  See the file
    COPYING included with this distribution for more information.
  }

  {$I SETTINGS.INC}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls;

type
  TAboutForm = class(TForm)
    OKButton: TButton;
    Label1: TLabel;
    Label2: TLabel;
    Version: TLabel;
    Copyright: TLabel;
    Label3: TLabel;
    WebSite: TLabel;
    Image1: TImage;
    Label6: TLabel;
    procedure OKButtonClick(Sender: TObject);
    procedure OKButtonKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure FormShow(Sender: TObject);
    procedure WebSiteClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  AboutForm: TAboutForm;

implementation

{$R *.DFM}

uses
  Main, ShellApi;


procedure TAboutForm.OKButtonClick(Sender: TObject);
begin
  Close
end;

procedure TAboutForm.OKButtonKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if Key = VK_ESCAPE then
    Close;
end;

procedure TAboutForm.FormShow(Sender: TObject);
begin
  if Version.Caption = 'Version' then
    Version.Caption := Version.Caption + ' ' + Main.VERSION_NUMBER;
  if Caption = 'About' then
    Caption := Caption + ' ' + APPL_NAME;
  Label1.Caption := APPL_NAME;
  Label2.Caption := APPL_NAME;
end;

procedure TAboutForm.WebSiteClick(Sender: TObject);
  var
    Param: string;
    URL: string;
begin
  Param := URL;
  URL := WebSite.Caption;
  ShellExecute (0, 'open', @URL[1], Nil, Nil, SW_SHOWNORMAL);
end;

end.
