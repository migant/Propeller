unit InfoForm;

  { TILE STUDIO

    Web site:    http://tilestudio.sourceforge.net/

    Written by:  Mike Wiering, University of Nijmegen
    E-mail:      mike@wieringsoftware.nl

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of the
    License, or (at your option) any later version.  See the file
    COPYING included with this distribution for more information.
  }

  {$I SETTINGS.INC}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TInfo = class(TForm)
    L0: TLabel;
    Label1: TLabel;
    Label2: TLabel;
    Author: TEdit;
    Notes: TMemo;
    Copyright: TMemo;
    CloseButton: TButton;
    Startup: TCheckBox;
    procedure CloseButtonClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Info: TInfo;

implementation

{$R *.DFM}

procedure TInfo.CloseButtonClick(Sender: TObject);
begin
  Close;
end;

end.
